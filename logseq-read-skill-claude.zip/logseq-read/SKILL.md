---
name: logseq-read
description: "Read and query the user's personal Logseq knowledge base (appunti, note, journal, task) at /Users/tommasobottazzi/Desktop/lavoro/logseq. ALWAYS use this skill before answering any question about the user's personal notes, knowledge, projects, or tasks — do not guess from memory. Trigger when the user asks about a person, project, or topic in their notes (\"leggi le note su X\", \"cosa so su Y\", \"chi è X\"); asks what they have to do (\"cosa ho da fare\", \"TODO aperti\", \"task in sospeso\"); asks about today or a past journal entry (\"journal di oggi\", \"cosa ho fatto ieri\"); wants to search their notes (\"cerca nelle note\", \"dove ho scritto di X\"); asks to list their pages or graph. Also trigger if the user asks about work, clients, projects, or personal plans."
---

# Logseq Read

Skill per leggere il graph Logseq dell'utente mantenendo gerarchia, wikilink, tag, proprietà e stato dei task.

**Graph path:** `/Users/tommasobottazzi/Desktop/lavoro/logseq`
- `pages/` → note su persone, progetti, argomenti
- `journals/` → diari giornalieri (`YYYY_MM_DD.md`)

---

## Esecuzione

Il percorso base di questa skill è indicato nell'intestazione "Base directory for this skill:" all'inizio di questo documento. Usa quel percorso per lo script:

```bash
python "/SKILL_BASE_DIR/scripts/parse_logseq.py" <ARGS>
```

Sostituisci `/SKILL_BASE_DIR` con il percorso base estratto dall'intestazione.

---

## Comandi disponibili

| Argomento | Quando usarlo |
|-----------|--------------|
| `--page "Nome"` | Leggi una pagina (persona, progetto, argomento) |
| `--journal today` | Journal di oggi |
| `--journal 2026-05-15` | Journal di una data specifica (ISO) |
| `--todos` | Tutti i task aperti (TODO/DOING/LATER) da tutte le note |
| `--search "termine"` | Ricerca full-text in tutte le note |
| `--list` | Lista tutte le pagine e i journal disponibili |

---

## Come mappare la richiesta dell'utente

- *"leggi le note su [nome/progetto]"* → `--page "[nome]"`
- *"cosa ho da fare / task aperti / TODO"* → `--todos`
- *"journal di oggi / cosa ho fatto oggi"* → `--journal today`
- *"journal del [data verbale o ISO]"* → `--journal YYYY-MM-DD`
- *"cerca [termine] nelle note"* → `--search "[termine]"`
- *"quali pagine ho / lista note"* → `--list`
- Domanda su una persona o progetto specifico → `--page "[nome]"`

Se la richiesta è ambigua, inizia con `--list` per mostrare le pagine disponibili, poi leggi quella pertinente.

---

## Struttura dell'output

Lo script restituisce markdown strutturato con:
- **Proprietà** della pagina (`title::`, `tags::`, `type::`, `status::`, ecc.)
- **Gerarchia** dei bullet point preservata (indentazione = profondità)
- **Task** con stato: `TODO`, `DOING`, `DONE`, `LATER`
- **Wikilink** come `[[Nome Pagina]]`
- **Scheduled** e annotazioni temporali

---

## Come usare l'output

1. Leggi le note con il comando appropriato
2. Rispondi alla domanda dell'utente sintetizzando le informazioni rilevanti
3. Cita sempre task aperti se presenti e pertinenti alla domanda
4. Se nell'output ci sono `[[Wikilink]]` a pagine correlate, offriti di leggerle anche quelle con `--page`
5. Non inventare mai informazioni non presenti nelle note — citale o ammetti che non ci sono

---

## Setup automatico

Lo script installa `logseq-matryca-parser` automaticamente se mancante.
In caso di errore di installazione, esegui manualmente:

```bash
pip install logseq-matryca-parser
```
